package com.example.lat_p7

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
