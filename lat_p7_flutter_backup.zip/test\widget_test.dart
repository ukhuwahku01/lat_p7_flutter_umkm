import 'package:flutter_test/flutter_test.dart';
import 'package:lat_p7/main.dart';

void main() {
  testWidgets('shows simulation page then opens reports page', (tester) async {
    await tester.pumpWidget(const UmkmSalesApp());

    expect(find.text('SIMULASI SAAT INI'), findsOneWidget);
    expect(find.text('Input Transaksi Baru'), findsOneWidget);

    await tester.tap(find.text('Reports'));
    await tester.pumpAndSettle();

    expect(find.text('Laporan Penjualan'), findsOneWidget);
    expect(find.text('TOTAL PENDAPATAN'), findsOneWidget);
  });
}
