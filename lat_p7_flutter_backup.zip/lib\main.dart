import 'package:flutter/material.dart';

void main() {
  runApp(const UmkmSalesApp());
}

class UmkmSalesApp extends StatelessWidget {
  const UmkmSalesApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'UMKM Sales Monitor',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF0D63B6),
          primary: const Color(0xFF0D63B6),
          secondary: const Color(0xFF85F184),
        ),
        scaffoldBackgroundColor: const Color(0xFFF5F7FC),
        fontFamily: 'Roboto',
        useMaterial3: true,
      ),
      home: const DashboardShell(),
    );
  }
}

class DashboardShell extends StatefulWidget {
  const DashboardShell({super.key});

  @override
  State<DashboardShell> createState() => _DashboardShellState();
}

class _DashboardShellState extends State<DashboardShell> {
  int _selectedIndex = 0;

  void _selectPage(int index) {
    setState(() => _selectedIndex = index);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: IndexedStack(
          index: _selectedIndex,
          children: [
            SimulationPage(onOpenReports: () => _selectPage(1)),
            ReportsPage(onBackToSimulation: () => _selectPage(0)),
          ],
        ),
      ),
      bottomNavigationBar: UmkmBottomNavigation(
        selectedIndex: _selectedIndex,
        onTap: _selectPage,
      ),
    );
  }
}

class SimulationPage extends StatelessWidget {
  const SimulationPage({super.key, required this.onOpenReports});

  final VoidCallback onOpenReports;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const HeaderBar(showStatus: true),
        Expanded(
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(18, 22, 18, 18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const CurrentSimulationCard(),
                const SizedBox(height: 22),
                const TransactionInputCard(),
                const SizedBox(height: 22),
                SectionTitle(
                  title: 'TRANSAKSI TERBARU',
                  action: 'Lihat Semua',
                  onActionTap: () {},
                ),
                const SizedBox(height: 10),
                const TransactionTile(
                  icon: Icons.local_cafe_outlined,
                  iconColor: Color(0xFF0E5FB3),
                  iconBackground: Color(0xFFDDEBFF),
                  product: 'Kopi Susu Aren',
                  category: 'Minuman',
                  total: 'Rp 36.000',
                  detail: '2 x 18.000',
                ),
                const SizedBox(height: 6),
                const TransactionTile(
                  icon: Icons.restaurant,
                  iconColor: Color(0xFF5A3510),
                  iconBackground: Color(0xFFFFD9A8),
                  product: 'Nasi Goreng Spesial',
                  category: 'Makanan',
                  total: 'Rp 25.000',
                  detail: '1 x 25.000',
                ),
                const SizedBox(height: 6),
                const TransactionTile(
                  icon: Icons.cleaning_services_outlined,
                  iconColor: Color(0xFF087D1D),
                  iconBackground: Color(0xFF8DF58A),
                  product: 'Cuci Sepatu Express',
                  category: 'Jasa',
                  total: 'Rp 50.000',
                  detail: '1 x 50.000',
                ),
                const SizedBox(height: 22),
                PerformanceBanner(onPressed: onOpenReports),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class ReportsPage extends StatelessWidget {
  const ReportsPage({super.key, required this.onBackToSimulation});

  final VoidCallback onBackToSimulation;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const HeaderBar(showStatus: false),
        Expanded(
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(18, 28, 18, 18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Laporan Penjualan',
                          style: TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.w800,
                            color: Color(0xFF101421),
                          ),
                        ),
                        SizedBox(height: 8),
                        Text(
                          'Periode: 1 - 31 Oktober 2023',
                          style: TextStyle(
                            fontSize: 16,
                            color: Color(0xFF3E4350),
                          ),
                        ),
                      ],
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 9,
                      ),
                      decoration: BoxDecoration(
                        color: const Color(0xFF8EF48D),
                        borderRadius: BorderRadius.circular(22),
                      ),
                      child: const Row(
                        children: [
                          Icon(
                            Icons.trending_up,
                            size: 18,
                            color: Color(0xFF07811D),
                          ),
                          SizedBox(width: 4),
                          Text(
                            '+12.5%',
                            style: TextStyle(
                              color: Color(0xFF07811D),
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 28),
                const RevenueCard(),
                const SizedBox(height: 18),
                const Row(
                  children: [
                    Expanded(
                      child: MetricCard(
                        title: 'Total Transaksi',
                        value: '154',
                        suffix: 'Order',
                        progress: .68,
                      ),
                    ),
                    SizedBox(width: 12),
                    Expanded(
                      child: MetricCard(
                        title: 'Rata-rata',
                        value: 'Rp 80.844',
                        subtitle: 'Per transaksi',
                        progress: 0,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 18),
                const SalesHighlightTile(
                  icon: Icons.arrow_upward,
                  iconBackground: Color(0xFF8EF48D),
                  iconColor: Color(0xFF08270D),
                  label: 'Penjualan Tertinggi',
                  amount: 'Rp 450.000',
                  date: '15 Okt',
                ),
                const SizedBox(height: 10),
                const SalesHighlightTile(
                  icon: Icons.arrow_downward,
                  iconBackground: Color(0xFFFFDAD7),
                  iconColor: Color(0xFFA30D0D),
                  label: 'Penjualan Terendah',
                  amount: 'Rp 15.000',
                  date: '02 Okt',
                ),
                const SizedBox(height: 34),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    onPressed: onBackToSimulation,
                    icon: const Icon(Icons.refresh, size: 24),
                    label: const Text('Kembali ke Simulasi'),
                    style: FilledButton.styleFrom(
                      backgroundColor: const Color(0xFF0B66B8),
                      foregroundColor: Colors.white,
                      minimumSize: const Size.fromHeight(64),
                      textStyle: const TextStyle(
                        fontSize: 23,
                        fontWeight: FontWeight.w800,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 34),
                const TipsBanner(),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class HeaderBar extends StatelessWidget {
  const HeaderBar({super.key, required this.showStatus});

  final bool showStatus;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 58,
      padding: const EdgeInsets.symmetric(horizontal: 18),
      decoration: const BoxDecoration(
        color: Color(0xFFF7F8FD),
        border: Border(bottom: BorderSide(color: Color(0xFFD0D6E2))),
      ),
      child: Row(
        children: [
          const Icon(Icons.menu, color: Color(0xFF0D63B6), size: 27),
          const SizedBox(width: 12),
          const Expanded(
            child: Text(
              'UMKM Sales\nMonitor',
              maxLines: 2,
              style: TextStyle(
                height: 1.08,
                color: Color(0xFF0758A7),
                fontSize: 24,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
          if (showStatus)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 9),
              decoration: BoxDecoration(
                color: const Color(0xFF8EF48D),
                borderRadius: BorderRadius.circular(22),
              ),
              child: const Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.circle, size: 8, color: Color(0xFF065F16)),
                  SizedBox(width: 6),
                  Text(
                    'Status:\nAktif',
                    style: TextStyle(
                      height: 1.0,
                      color: Color(0xFF065F16),
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
          const SizedBox(width: 12),
          const Icon(Icons.account_circle_outlined, color: Color(0xFF28313F)),
        ],
      ),
    );
  }
}

class CurrentSimulationCard extends StatelessWidget {
  const CurrentSimulationCard({super.key});

  @override
  Widget build(BuildContext context) {
    return InfoCard(
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: const [
                Text('SIMULASI SAAT INI', style: LabelStyle.text),
                SizedBox(height: 10),
                Text(
                  'Rp 4.250.000',
                  style: TextStyle(
                    color: Color(0xFF0758A7),
                    fontSize: 30,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                SizedBox(height: 8),
                Text(
                  'Estimasi Pendapatan Harian',
                  style: TextStyle(color: Color(0xFF4F5663), fontSize: 14),
                ),
              ],
            ),
          ),
          const Row(
            children: [
              Icon(Icons.trending_up, color: Color(0xFF087D1D), size: 18),
              SizedBox(width: 4),
              Text(
                '+12%',
                style: TextStyle(
                  color: Color(0xFF087D1D),
                  fontWeight: FontWeight.w800,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class TransactionInputCard extends StatelessWidget {
  const TransactionInputCard({super.key});

  @override
  Widget build(BuildContext context) {
    return InfoCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Icon(Icons.add_business_outlined, color: Color(0xFF0D63B6)),
              SizedBox(width: 10),
              Text(
                'Input Transaksi Baru',
                style: TextStyle(
                  fontSize: 20,
                  color: Color(0xFF101421),
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          const FieldLabel('Nama Produk'),
          const SizedBox(height: 6),
          const MockInputField(text: 'Contoh: Kopi Susu Aren'),
          const SizedBox(height: 8),
          const FieldLabel('Kategori Produk'),
          const SizedBox(height: 6),
          const MockInputField(text: 'Makanan', trailing: Icons.expand_more),
          const SizedBox(height: 8),
          const Row(
            children: [
              Expanded(child: FieldLabel('Jumlah')),
              SizedBox(width: 10),
              Expanded(child: FieldLabel('Harga Satuan')),
            ],
          ),
          const SizedBox(height: 6),
          const Row(
            children: [
              Expanded(child: MockInputField(text: '0')),
              SizedBox(width: 10),
              Expanded(child: MockInputField(text: 'Rp 0')),
            ],
          ),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              onPressed: () {},
              icon: const Icon(Icons.add_circle_outline, size: 22),
              label: const Text('Tambah Transaksi'),
              style: FilledButton.styleFrom(
                backgroundColor: const Color(0xFF2383DD),
                foregroundColor: Colors.white,
                minimumSize: const Size.fromHeight(56),
                textStyle: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w800,
                ),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class FieldLabel extends StatelessWidget {
  const FieldLabel(this.text, {super.key});

  final String text;

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: const TextStyle(
        color: Color(0xFF424957),
        fontSize: 12,
        fontWeight: FontWeight.w800,
      ),
    );
  }
}

class MockInputField extends StatelessWidget {
  const MockInputField({super.key, required this.text, this.trailing});

  final String text;
  final IconData? trailing;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 40,
      padding: const EdgeInsets.symmetric(horizontal: 14),
      decoration: BoxDecoration(
        color: const Color(0xFFF7F8FD),
        border: Border.all(color: const Color(0xFF727B8C), width: 1.1),
        borderRadius: BorderRadius.circular(7),
      ),
      child: Row(
        children: [
          Expanded(
            child: Text(
              text,
              style: const TextStyle(color: Color(0xFF6E7480), fontSize: 16),
            ),
          ),
          if (trailing != null)
            Icon(trailing, color: const Color(0xFF6E7480), size: 20),
        ],
      ),
    );
  }
}

class TransactionTile extends StatelessWidget {
  const TransactionTile({
    super.key,
    required this.icon,
    required this.iconColor,
    required this.iconBackground,
    required this.product,
    required this.category,
    required this.total,
    required this.detail,
  });

  final IconData icon;
  final Color iconColor;
  final Color iconBackground;
  final String product;
  final String category;
  final String total;
  final String detail;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFFEFF4FC),
        border: Border.all(color: const Color(0xFFC5CEDD), width: 1.2),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        children: [
          CircleAvatar(
            radius: 20,
            backgroundColor: iconBackground,
            child: Icon(icon, color: iconColor),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  product,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w800,
                    color: Color(0xFF121722),
                  ),
                ),
                const SizedBox(height: 6),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 3,
                  ),
                  decoration: BoxDecoration(
                    color: const Color(0xFFD5E2F6),
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: Text(
                    category,
                    style: const TextStyle(
                      fontSize: 12,
                      color: Color(0xFF3D597E),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                total,
                style: const TextStyle(
                  color: Color(0xFF101421),
                  fontWeight: FontWeight.w900,
                ),
              ),
              Text(
                detail,
                style: const TextStyle(color: Color(0xFF252B36), fontSize: 12),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class SectionTitle extends StatelessWidget {
  const SectionTitle({
    super.key,
    required this.title,
    required this.action,
    required this.onActionTap,
  });

  final String title;
  final String action;
  final VoidCallback onActionTap;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(title, style: LabelStyle.text),
        GestureDetector(
          onTap: onActionTap,
          child: Text(
            action,
            style: const TextStyle(
              color: Color(0xFF0758A7),
              fontWeight: FontWeight.w800,
            ),
          ),
        ),
      ],
    );
  }
}

class PerformanceBanner extends StatelessWidget {
  const PerformanceBanner({super.key, required this.onPressed});

  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 122,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(13),
        gradient: const LinearGradient(
          colors: [Color(0xFF0F7781), Color(0xFF0B6DBE)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: Stack(
        children: [
          Positioned.fill(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(18, 18, 18, 18),
              child: CustomPaint(painter: ChartLinesPainter()),
            ),
          ),
          const Positioned(
            left: 16,
            bottom: 18,
            right: 160,
            child: Text(
              'Pantau performa penjualan Anda\nmelalui simulasi cerdas kami.',
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w800,
                height: 1.25,
              ),
            ),
          ),
          Positioned(
            right: 0,
            bottom: 0,
            child: FilledButton.icon(
              onPressed: onPressed,
              icon: const Icon(Icons.bar_chart, size: 24),
              label: const Text('Lihat Laporan'),
              style: FilledButton.styleFrom(
                backgroundColor: const Color(0xFF0B66B8),
                foregroundColor: Colors.white,
                minimumSize: const Size(150, 56),
                shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(28),
                    bottomRight: Radius.circular(13),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class RevenueCard extends StatelessWidget {
  const RevenueCard({super.key});

  @override
  Widget build(BuildContext context) {
    return InfoCard(
      borderColor: const Color(0xFFC5CEDD),
      leadingStripe: const Color(0xFF087D1D),
      child: Row(
        children: [
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('TOTAL PENDAPATAN', style: LabelStyle.text),
                SizedBox(height: 28),
                Text(
                  'Rp 12.450.000',
                  style: TextStyle(
                    color: Color(0xFF087D1D),
                    fontSize: 31,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                SizedBox(height: 8),
                Row(
                  children: [
                    Icon(
                      Icons.check_circle_outline,
                      color: Color(0xFF087D1D),
                      size: 16,
                    ),
                    SizedBox(width: 4),
                    Text(
                      'Target bulanan tercapai 85%',
                      style: TextStyle(
                        color: Color(0xFF087D1D),
                        fontSize: 12,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          CircleAvatar(
            radius: 22,
            backgroundColor: const Color(0xFF8EF48D),
            child: const Icon(
              Icons.payments_outlined,
              color: Color(0xFF087D1D),
            ),
          ),
        ],
      ),
    );
  }
}

class MetricCard extends StatelessWidget {
  const MetricCard({
    super.key,
    required this.title,
    required this.value,
    this.suffix,
    this.subtitle,
    required this.progress,
  });

  final String title;
  final String value;
  final String? suffix;
  final String? subtitle;
  final double progress;

  @override
  Widget build(BuildContext context) {
    return InfoCard(
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: LabelStyle.text),
          const SizedBox(height: 10),
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Flexible(
                child: Text(
                  value,
                  style: const TextStyle(
                    color: Color(0xFF060B19),
                    fontSize: 24,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
              if (suffix != null) ...[
                const SizedBox(width: 4),
                Padding(
                  padding: const EdgeInsets.only(bottom: 4),
                  child: Text(
                    suffix!,
                    style: const TextStyle(
                      color: Color(0xFF4F5663),
                      fontSize: 12,
                    ),
                  ),
                ),
              ],
            ],
          ),
          if (subtitle != null) ...[
            const SizedBox(height: 4),
            Text(
              subtitle!,
              style: const TextStyle(
                color: Color(0xFF087D1D),
                fontSize: 12,
                fontWeight: FontWeight.w800,
              ),
            ),
          ],
          if (progress > 0) ...[
            const SizedBox(height: 12),
            ClipRRect(
              borderRadius: BorderRadius.circular(2),
              child: LinearProgressIndicator(
                value: progress,
                minHeight: 4,
                backgroundColor: const Color(0xFFDCE7FA),
                color: const Color(0xFF0B66B8),
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class SalesHighlightTile extends StatelessWidget {
  const SalesHighlightTile({
    super.key,
    required this.icon,
    required this.iconBackground,
    required this.iconColor,
    required this.label,
    required this.amount,
    required this.date,
  });

  final IconData icon;
  final Color iconBackground;
  final Color iconColor;
  final String label;
  final String amount;
  final String date;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFFEFF4FC),
        border: Border.all(color: const Color(0xFFC5CEDD), width: 1.2),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        children: [
          Container(
            height: 39,
            width: 39,
            decoration: BoxDecoration(
              color: iconBackground,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, color: iconColor, size: 30),
          ),
          const SizedBox(width: 18),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: const TextStyle(
                    color: Color(0xFF6A7280),
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  amount,
                  style: const TextStyle(
                    color: Color(0xFF101421),
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ],
            ),
          ),
          Text(date, style: const TextStyle(color: Color(0xFF6A7280))),
        ],
      ),
    );
  }
}

class TipsBanner extends StatelessWidget {
  const TipsBanner({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 173,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(15),
        gradient: const LinearGradient(
          colors: [Color(0xFF203A4A), Color(0xFF0F6C7C)],
          begin: Alignment.bottomLeft,
          end: Alignment.topRight,
        ),
      ),
      child: Stack(
        children: [
          Positioned.fill(child: CustomPaint(painter: ChartLinesPainter())),
          const Align(
            alignment: Alignment.bottomLeft,
            child: Text(
              'Tips UMKM\nOptimalkan stok pada akhir pekan untuk\nmeningkatkan rata-rata penjualan.',
              style: TextStyle(
                color: Colors.white,
                fontSize: 15,
                height: 1.18,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class InfoCard extends StatelessWidget {
  const InfoCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(18),
    this.borderColor = const Color(0xFFC5CEDD),
    this.leadingStripe,
  });

  final Widget child;
  final EdgeInsets padding;
  final Color borderColor;
  final Color? leadingStripe;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: borderColor, width: 1.2),
        borderRadius: BorderRadius.circular(11),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(10),
        child: Stack(
          children: [
            if (leadingStripe != null)
              Positioned(
                left: 0,
                top: 0,
                bottom: 0,
                child: Container(width: 4, color: leadingStripe),
              ),
            Padding(
              padding: padding.copyWith(
                left: padding.left + (leadingStripe == null ? 0 : 4),
              ),
              child: child,
            ),
          ],
        ),
      ),
    );
  }
}

class UmkmBottomNavigation extends StatelessWidget {
  const UmkmBottomNavigation({
    super.key,
    required this.selectedIndex,
    required this.onTap,
  });

  final int selectedIndex;
  final ValueChanged<int> onTap;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 74,
      decoration: const BoxDecoration(
        color: Color(0xFFF7F8FD),
        border: Border(top: BorderSide(color: Color(0xFFD0D6E2))),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          BottomNavItem(
            icon: Icons.calculate_outlined,
            label: 'Simulation',
            selected: selectedIndex == 0,
            onTap: () => onTap(0),
          ),
          BottomNavItem(
            icon: Icons.insert_chart_outlined,
            label: 'Reports',
            selected: selectedIndex == 1,
            onTap: () => onTap(1),
          ),
        ],
      ),
    );
  }
}

class BottomNavItem extends StatelessWidget {
  const BottomNavItem({
    super.key,
    required this.icon,
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final IconData icon;
  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final color = selected ? const Color(0xFF087D1D) : const Color(0xFF28313F);
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(11),
      child: Container(
        width: 88,
        height: 55,
        decoration: BoxDecoration(
          color: selected ? const Color(0xFF8EF48D) : Colors.transparent,
          borderRadius: BorderRadius.circular(11),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: color, size: 20),
            Text(
              label,
              style: TextStyle(
                color: color,
                fontSize: 12,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class ChartLinesPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final gridPaint =
        Paint()
          ..color = Colors.white.withValues(alpha: .16)
          ..strokeWidth = 1;
    final linePaint =
        Paint()
          ..color = const Color(0xFFC8F0FF).withValues(alpha: .9)
          ..strokeWidth = 3
          ..style = PaintingStyle.stroke;
    final barPaint = Paint()..color = Colors.white.withValues(alpha: .24);

    for (var i = 1; i < 5; i++) {
      final y = size.height * i / 5;
      canvas.drawLine(Offset(0, y), Offset(size.width, y), gridPaint);
    }

    final path =
        Path()
          ..moveTo(0, size.height * .78)
          ..lineTo(size.width * .16, size.height * .57)
          ..lineTo(size.width * .31, size.height * .66)
          ..lineTo(size.width * .47, size.height * .38)
          ..lineTo(size.width * .66, size.height * .46)
          ..lineTo(size.width * .82, size.height * .22)
          ..lineTo(size.width, size.height * .3);
    canvas.drawPath(path, linePaint);

    for (var i = 0; i < 9; i++) {
      final x = size.width * (.08 + (i * .085));
      final h = size.height * (.2 + (i % 4) * .08);
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromLTWH(x, size.height - h, 8, h),
          const Radius.circular(3),
        ),
        barPaint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class LabelStyle {
  static const text = TextStyle(
    color: Color(0xFF687080),
    fontSize: 12,
    fontWeight: FontWeight.w900,
    letterSpacing: 1.2,
  );
}
