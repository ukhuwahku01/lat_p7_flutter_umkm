# Generated code do not commit.
file(TO_CMAKE_PATH "C:\\flutter_windows_3.29.3-stable\\flutter" FLUTTER_ROOT)
file(TO_CMAKE_PATH "D:\\PROJEK FLUTTER\\LAT P7" PROJECT_DIR)

set(FLUTTER_VERSION "1.0.0+1" PARENT_SCOPE)
set(FLUTTER_VERSION_MAJOR 1 PARENT_SCOPE)
set(FLUTTER_VERSION_MINOR 0 PARENT_SCOPE)
set(FLUTTER_VERSION_PATCH 0 PARENT_SCOPE)
set(FLUTTER_VERSION_BUILD 1 PARENT_SCOPE)

# Environment variables to pass to tool_backend.sh
list(APPEND FLUTTER_TOOL_ENVIRONMENT
  "FLUTTER_ROOT=C:\\flutter_windows_3.29.3-stable\\flutter"
  "PROJECT_DIR=D:\\PROJEK FLUTTER\\LAT P7"
  "FLUTTER_ROOT=C:\\flutter_windows_3.29.3-stable\\flutter"
  "FLUTTER_EPHEMERAL_DIR=D:\\PROJEK FLUTTER\\LAT P7\\windows\\flutter\\ephemeral"
  "PROJECT_DIR=D:\\PROJEK FLUTTER\\LAT P7"
  "FLUTTER_TARGET=D:\\PROJEK FLUTTER\\LAT P7\\lib\\main.dart"
  "DART_OBFUSCATION=false"
  "TRACK_WIDGET_CREATION=true"
  "TREE_SHAKE_ICONS=false"
  "PACKAGE_CONFIG=D:\\PROJEK FLUTTER\\LAT P7\\.dart_tool\\package_config.json"
)
