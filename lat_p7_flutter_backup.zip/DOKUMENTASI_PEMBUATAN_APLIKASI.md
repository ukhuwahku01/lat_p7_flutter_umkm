# Dokumentasi Pembuatan Aplikasi UMKM Sales Monitor

## 1. Judul Program

**UMKM Sales Monitor**

Aplikasi ini dibuat menggunakan **Flutter** dengan bahasa pemrograman **Dart**. Aplikasi memiliki dua halaman utama:

1. **Simulation** sebagai halaman awal.
2. **Reports** sebagai halaman kedua.

Tampilan aplikasi dibuat berdasarkan gambar referensi H1 dan H2.

## 2. Tujuan Program

Tujuan aplikasi ini adalah menampilkan simulasi penjualan UMKM dan laporan penjualan secara sederhana. Aplikasi menampilkan estimasi pendapatan, input transaksi, daftar transaksi terbaru, total pendapatan, total transaksi, rata-rata transaksi, serta informasi penjualan tertinggi dan terendah.

## 3. Teknologi yang Digunakan

- Flutter
- Dart
- Material Design
- Android Emulator dari Android Studio

## 4. Membuat Project Flutter

Langkah pertama adalah membuat project Flutter.

```powershell
flutter create --project-name lat_p7 .
```

Nama project menggunakan `lat_p7` karena nama package Flutter harus menggunakan huruf kecil, angka, dan underscore. Nama package tidak boleh menggunakan spasi atau huruf kapital.

Setelah project dibuat, struktur folder utama adalah:

```text
lib/
  main.dart

test/
  widget_test.dart

android/
ios/
web/
windows/
pubspec.yaml
```

File utama program berada di:

```text
lib/main.dart
```

## 5. Perancangan Tampilan Aplikasi

Berdasarkan gambar referensi:

- Gambar H2 digunakan sebagai halaman awal atau halaman **Simulation**.
- Gambar H1 digunakan sebagai halaman kedua atau halaman **Reports**.

Aplikasi menggunakan bottom navigation dengan dua menu:

```text
Simulation
Reports
```

Alur aplikasi:

```text
Aplikasi dibuka
Masuk ke halaman Simulation
User dapat melihat simulasi penjualan
User menekan menu Reports atau tombol Lihat Laporan
Masuk ke halaman Reports
User dapat kembali ke halaman Simulation
```

## 6. Membuat Root Aplikasi

Program dimulai dari fungsi `main()`.

```dart
void main() {
  runApp(const UmkmSalesApp());
}
```

Kemudian dibuat class utama aplikasi.

```dart
class UmkmSalesApp extends StatelessWidget {
  const UmkmSalesApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'UMKM Sales Monitor',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF0D63B6),
        ),
        scaffoldBackgroundColor: const Color(0xFFF5F7FC),
        useMaterial3: true,
      ),
      home: const DashboardShell(),
    );
  }
}
```

Penjelasan:

- `MaterialApp` digunakan sebagai struktur utama aplikasi Flutter.
- `debugShowCheckedModeBanner: false` digunakan untuk menghilangkan tulisan debug.
- `theme` digunakan untuk mengatur tema warna aplikasi.
- `home` diarahkan ke `DashboardShell`.

## 7. Membuat Navigasi Halaman

Navigasi aplikasi dibuat menggunakan class `DashboardShell`.

```dart
class DashboardShell extends StatefulWidget {
  const DashboardShell({super.key});

  @override
  State<DashboardShell> createState() => _DashboardShellState();
}
```

Class ini dibuat sebagai `StatefulWidget` karena perlu menyimpan halaman yang sedang aktif.

```dart
int _selectedIndex = 0;
```

Nilai `0` berarti halaman yang aktif adalah halaman Simulation.

```dart
void _selectPage(int index) {
  setState(() => _selectedIndex = index);
}
```

Fungsi tersebut digunakan untuk mengganti halaman ketika tombol navigasi ditekan.

Bagian utama navigasi:

```dart
Scaffold(
  body: SafeArea(
    child: IndexedStack(
      index: _selectedIndex,
      children: [
        SimulationPage(onOpenReports: () => _selectPage(1)),
        ReportsPage(onBackToSimulation: () => _selectPage(0)),
      ],
    ),
  ),
  bottomNavigationBar: UmkmBottomNavigation(
    selectedIndex: _selectedIndex,
    onTap: _selectPage,
  ),
);
```

`IndexedStack` digunakan untuk menampilkan halaman sesuai index yang dipilih.

## 8. Membuat Header Aplikasi

Header aplikasi dibuat menggunakan widget `HeaderBar`.

Isi header:

- Icon menu
- Judul UMKM Sales Monitor
- Badge status aktif
- Icon akun pengguna

```dart
class HeaderBar extends StatelessWidget {
  const HeaderBar({super.key, required this.showStatus});

  final bool showStatus;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 58,
      padding: const EdgeInsets.symmetric(horizontal: 18),
      child: Row(
        children: [
          const Icon(Icons.menu),
          const Text('UMKM Sales\nMonitor'),
          if (showStatus)
            Container(
              child: const Text('Status:\nAktif'),
            ),
          const Icon(Icons.account_circle_outlined),
        ],
      ),
    );
  }
}
```

Pada halaman Simulation, status ditampilkan. Pada halaman Reports, status tidak ditampilkan.

## 9. Membuat Halaman Simulation

Halaman Simulation adalah halaman awal aplikasi.

Komponen yang ditampilkan:

- Header aplikasi
- Kartu simulasi saat ini
- Form input transaksi baru
- Daftar transaksi terbaru
- Banner untuk membuka laporan

Struktur halaman:

```dart
class SimulationPage extends StatelessWidget {
  const SimulationPage({super.key, required this.onOpenReports});

  final VoidCallback onOpenReports;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const HeaderBar(showStatus: true),
        Expanded(
          child: SingleChildScrollView(
            child: Column(
              children: [
                const CurrentSimulationCard(),
                const TransactionInputCard(),
                const TransactionTile(),
                PerformanceBanner(onPressed: onOpenReports),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
```

`SingleChildScrollView` digunakan agar halaman tetap bisa digulir ketika layar kecil.

## 10. Membuat Kartu Simulasi Saat Ini

Kartu simulasi menampilkan estimasi pendapatan harian.

Data yang ditampilkan:

```text
SIMULASI SAAT INI
Rp 4.250.000
Estimasi Pendapatan Harian
+12%
```

Widget yang digunakan adalah `CurrentSimulationCard`.

```dart
class CurrentSimulationCard extends StatelessWidget {
  const CurrentSimulationCard({super.key});

  @override
  Widget build(BuildContext context) {
    return InfoCard(
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: const [
                Text('SIMULASI SAAT INI'),
                Text('Rp 4.250.000'),
                Text('Estimasi Pendapatan Harian'),
              ],
            ),
          ),
          const Row(
            children: [
              Icon(Icons.trending_up),
              Text('+12%'),
            ],
          ),
        ],
      ),
    );
  }
}
```

## 11. Membuat Form Input Transaksi

Form input transaksi dibuat pada widget `TransactionInputCard`.

Isi form:

- Nama produk
- Kategori produk
- Jumlah
- Harga satuan
- Tombol tambah transaksi

```dart
class TransactionInputCard extends StatelessWidget {
  const TransactionInputCard({super.key});

  @override
  Widget build(BuildContext context) {
    return InfoCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Input Transaksi Baru'),
          const FieldLabel('Nama Produk'),
          const MockInputField(text: 'Contoh: Kopi Susu Aren'),
          const FieldLabel('Kategori Produk'),
          const MockInputField(text: 'Makanan'),
          FilledButton.icon(
            onPressed: () {},
            icon: const Icon(Icons.add_circle_outline),
            label: const Text('Tambah Transaksi'),
          ),
        ],
      ),
    );
  }
}
```

Pada program ini, input masih berupa tampilan statis. Jika ingin membuat input benar-benar berfungsi, field dapat diganti menjadi `TextField` dan data disimpan menggunakan `TextEditingController`.

## 12. Membuat Daftar Transaksi Terbaru

Daftar transaksi dibuat menggunakan widget `TransactionTile`.

Contoh data transaksi:

```text
Kopi Susu Aren
Minuman
Rp 36.000
2 x 18.000
```

```dart
TransactionTile(
  icon: Icons.local_cafe_outlined,
  product: 'Kopi Susu Aren',
  category: 'Minuman',
  total: 'Rp 36.000',
  detail: '2 x 18.000',
)
```

Widget `TransactionTile` dibuat reusable agar dapat digunakan untuk beberapa transaksi.

## 13. Membuat Banner Lihat Laporan

Banner pada bagian bawah halaman Simulation dibuat menggunakan widget `PerformanceBanner`.

Banner ini memiliki tombol:

```text
Lihat Laporan
```

Ketika tombol ditekan, aplikasi berpindah ke halaman Reports.

```dart
PerformanceBanner(onPressed: onOpenReports)
```

## 14. Membuat Halaman Reports

Halaman Reports adalah halaman kedua aplikasi.

Komponen yang ditampilkan:

- Header aplikasi
- Judul laporan penjualan
- Periode laporan
- Total pendapatan
- Total transaksi
- Rata-rata transaksi
- Penjualan tertinggi
- Penjualan terendah
- Tombol kembali ke simulasi
- Banner tips UMKM

Struktur halaman:

```dart
class ReportsPage extends StatelessWidget {
  const ReportsPage({super.key, required this.onBackToSimulation});

  final VoidCallback onBackToSimulation;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const HeaderBar(showStatus: false),
        Expanded(
          child: SingleChildScrollView(
            child: Column(
              children: [
                const RevenueCard(),
                const MetricCard(),
                const SalesHighlightTile(),
                FilledButton.icon(
                  onPressed: onBackToSimulation,
                  icon: const Icon(Icons.refresh),
                  label: const Text('Kembali ke Simulasi'),
                ),
                const TipsBanner(),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
```

## 15. Membuat Kartu Total Pendapatan

Kartu total pendapatan dibuat menggunakan widget `RevenueCard`.

Isi kartu:

```text
TOTAL PENDAPATAN
Rp 12.450.000
Target bulanan tercapai 85%
```

```dart
class RevenueCard extends StatelessWidget {
  const RevenueCard({super.key});

  @override
  Widget build(BuildContext context) {
    return InfoCard(
      leadingStripe: const Color(0xFF087D1D),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: const [
          Text('TOTAL PENDAPATAN'),
          Text('Rp 12.450.000'),
          Text('Target bulanan tercapai 85%'),
        ],
      ),
    );
  }
}
```

## 16. Membuat Kartu Statistik

Kartu statistik dibuat menggunakan widget `MetricCard`.

Contoh statistik:

```text
Total Transaksi: 154 Order
Rata-rata: Rp 80.844 per transaksi
```

Widget `MetricCard` dibuat reusable agar dapat digunakan untuk beberapa jenis statistik.

```dart
MetricCard(
  title: 'Total Transaksi',
  value: '154',
  suffix: 'Order',
  progress: .68,
)
```

## 17. Membuat Informasi Penjualan Tertinggi dan Terendah

Informasi ini dibuat menggunakan widget `SalesHighlightTile`.

Contoh:

```dart
SalesHighlightTile(
  icon: Icons.arrow_upward,
  label: 'Penjualan Tertinggi',
  amount: 'Rp 450.000',
  date: '15 Okt',
)
```

Widget ini juga digunakan untuk menampilkan penjualan terendah.

## 18. Membuat Bottom Navigation

Bottom navigation dibuat menggunakan widget `UmkmBottomNavigation`.

Menu yang tersedia:

```text
Simulation
Reports
```

Kode item navigasi:

```dart
BottomNavItem(
  icon: Icons.calculate_outlined,
  label: 'Simulation',
  selected: selectedIndex == 0,
  onTap: () => onTap(0),
)
```

Jika item aktif, maka warna background berubah menjadi hijau.

## 19. Membuat Komponen Reusable

Agar kode lebih rapi, beberapa bagian UI dibuat menjadi widget terpisah:

```text
InfoCard
FieldLabel
MockInputField
TransactionTile
MetricCard
SalesHighlightTile
BottomNavItem
```

Manfaat komponen reusable:

- Kode lebih mudah dibaca.
- Tampilan lebih konsisten.
- Komponen dapat dipakai ulang.
- Perubahan desain lebih mudah dilakukan.

## 20. Menjalankan Format Kode

Setelah kode selesai dibuat, format kode dengan perintah:

```powershell
dart format lib/main.dart test/widget_test.dart
```

Jika perintah `dart` tidak berjalan, gunakan Dart dari folder Flutter:

```powershell
C:\flutter_windows_3.29.3-stable\flutter\bin\cache\dart-sdk\bin\dart.exe format lib\main.dart test\widget_test.dart
```

## 21. Mengecek Error Program

Jalankan perintah berikut:

```powershell
flutter analyze
```

Jika tidak ada error, hasilnya:

```text
No issues found!
```

## 22. Menjalankan Test

Jalankan test dengan perintah:

```powershell
flutter test
```

Jika test berhasil, hasilnya:

```text
All tests passed!
```

## 23. Menjalankan Aplikasi di Emulator Android

Cek daftar emulator:

```powershell
flutter emulators
```

Contoh emulator:

```text
Medium_Phone_API_36
```

Jalankan emulator:

```powershell
flutter emulators --launch Medium_Phone_API_36
```

Cek device yang aktif:

```powershell
flutter devices
```

Jika emulator sudah aktif, biasanya muncul seperti ini:

```text
emulator-5554 • android-x64
```

Jalankan aplikasi:

```powershell
flutter run -d emulator-5554
```

## 24. Kesimpulan

Aplikasi UMKM Sales Monitor berhasil dibuat menggunakan Flutter dan Dart. Aplikasi memiliki dua halaman utama, yaitu halaman Simulation dan Reports. Tampilan UI dibuat berdasarkan gambar referensi H1 dan H2, serta dilengkapi navigasi bawah untuk berpindah halaman.

Program ini masih dapat dikembangkan lagi, misalnya dengan:

- Membuat form input transaksi benar-benar berfungsi.
- Menyimpan data transaksi ke database lokal.
- Menghitung total pendapatan secara otomatis.
- Menambahkan grafik penjualan.
- Membuat login pengguna.

